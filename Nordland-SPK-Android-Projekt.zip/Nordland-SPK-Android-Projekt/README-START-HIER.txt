NORDLAND SCHICHTPLAN – ANDROID-PROJEKT

WAS DU HIER BEKOMMST
- Deine aktuelle Nordland-App ist vollständig in app/src/main/assets/index.html eingebaut.
- Die Android-App startet diese Datei lokal. Sie braucht zum Starten kein Internet.
- Das App-Symbol verwendet das UPM-Emblem aus deiner vorhandenen Nordland-Dashboard-Abbildung.
- GitHub Actions ist vorbereitet, um daraus eine erste Test-APK zu bauen.

WICHTIG
Dies ist die erste Android-Teststufe, noch nicht die fertige Veröffentlichungs-App.
Noch NICHT enthalten: automatischer Inhalts-Updater von GitHub, zuverlässige native Erinnerungen bei geschlossener App und der endgültige Release-Signaturschlüssel.
Die APK wurde hier noch nicht auf einem Samsung-Gerät gebaut/installiert/getestet.
Bitte vor dem ersten Installationsversuch in deiner bisherigen App eine Datensicherung exportieren. Es werden keine Daten absichtlich gelöscht.

SO GEHT ES WEITER
1. Auf GitHub ein neues leeres Repository anlegen, zum Beispiel Nordland-SPK-Android.
2. Den Inhalt dieses entpackten Projektordners in das Repository hochladen. Auch den versteckten Ordner .github mit hochladen.
3. Im Repository oben auf Actions tippen.
4. Den Ablauf „Build Nordland APK“ öffnen und „Run workflow“ wählen (oder den ersten Upload abwarten).
5. Wenn der Lauf grün/erfolgreich ist, unten bei Artifacts „Nordland-SPK-APK“ herunterladen.
6. Das Artifact-ZIP entpacken. Darin befindet sich app-debug.apk.

Paketkennung: de.nordlandpapier.schichtplan
Diese Kennung muss für spätere Updates gleich bleiben.
