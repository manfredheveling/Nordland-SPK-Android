TECHNISCHER STAND

1. Erste Test-APK: vollständige HTML-App im APK-Asset-Ordner.
2. WebView nutzt WebViewAssetLoader mit stabiler lokaler Adresse:
   https://appassets.androidplatform.net/assets/
3. Dadurch bleibt die WebView-Origin bei späteren APK-Versionen gleich; localStorage/IndexedDB sollen so erhalten bleiben. Das muss vor einer Verteilung durch ein echtes Upgrade getestet werden.
4. Noch zu entwickeln: Inhalts-Updater mit versionierten GitHub-Paketen, SHA-256-Prüfung, Staging, atomarer Aktivierung und Rollback.
5. Noch zu entwickeln: native Android-Erinnerungen, die auch bei geschlossener App zuverlässig funktionieren.
6. Vor Veröffentlichung: dauerhaften privaten Release-Signaturschlüssel sichern. Niemals Schlüssel oder Passwörter ins GitHub-Repository laden.

Die Debug-Test-APK ist noch nicht die finale Kollegen-Version.
